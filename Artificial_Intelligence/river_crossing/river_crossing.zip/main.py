# main.py
from bfs import bfs
from dfs import dfs

# Define initial and goal states
initial_state = (0, 0, 0, 0)  # (Man, Leopard, Goat, Grass)
goal_state = (1, 1, 1, 1)  # Everything safely across

# Run BFS
bfs_solution = bfs(initial_state, goal_state)
print("BFS Solution Path:", bfs_solution)

# Run DFS
dfs_solution = dfs(initial_state, goal_state)
print("DFS Solution Path:", dfs_solution)
