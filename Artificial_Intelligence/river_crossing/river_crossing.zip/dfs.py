# dfs.py
from state import get_neighbors

def dfs(initial_state, goal_state):
    stack = [(initial_state, [])]
    visited = set()

    while stack:
        state, path = stack.pop()
        print(f"Exploring: {state}")  # Debugging Output

        if state == goal_state:
            return path + [state]  # Return solution path

        if state in visited:
            continue
        visited.add(state)  # Mark state as visited

        for neighbor in get_neighbors(state):
            if neighbor not in visited:
                stack.append((neighbor, path + [state]))

    print("No solution found using DFS.")
    return None
