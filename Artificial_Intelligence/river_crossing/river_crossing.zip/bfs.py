# bfs.py
from collections import deque
from state import get_neighbors

def bfs(initial_state, goal_state):
    queue = deque([(initial_state, [])])
    visited = set()

    while queue:
        state, path = queue.popleft()
        print(f"Exploring: {state}")  # Debugging Output

        if state == goal_state:
            return path + [state]  # Return solution path

        if state in visited:
            continue
        visited.add(state)  # Mark state as visited

        for neighbor in get_neighbors(state):
            if neighbor not in visited:
                queue.append((neighbor, path + [state]))

    print("No solution found using BFS.")
    return None
